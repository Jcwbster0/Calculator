//
//  ViewController.swift
//  Calculator
//
//  Created by Justin Webster on 5/17/21.
//

import UIKit

class ViewController: UIViewController {

    //MARK: - Outlets
    @IBOutlet weak var answerTextLabel: UILabel!
    @IBOutlet weak var equationTextLabel: UILabel!
    
    //MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    //MARK: - Properties
    var numbersArray:[String] = []
    var operand: String = ""
    var storedValue: Double = 0
    var ansWasTapped: Bool = false
    
    //MARK: - ACtions
    //number actions
    @IBAction func zeroButtonTapped(_ sender: Any) {
        checkIfAnsWasTapped()
        addNumberToAnswerTextLabel(number: "0")
    }
    @IBAction func oneButtonTapped(_ sender: Any) {
        checkIfAnsWasTapped()
        addNumberToAnswerTextLabel(number: "1")
    }
    @IBAction func twoButtonTapped(_ sender: Any) {
        checkIfAnsWasTapped()
        addNumberToAnswerTextLabel(number: "2")
    }
    @IBAction func threeButtonTapped(_ sender: Any) {
        checkIfAnsWasTapped()
        addNumberToAnswerTextLabel(number: "3")
    }
    @IBAction func fourButtonTapped(_ sender: Any) {
        checkIfAnsWasTapped()
        addNumberToAnswerTextLabel(number: "4")
    }
    @IBAction func fiveButtonTapped(_ sender: Any) {
        checkIfAnsWasTapped()
        addNumberToAnswerTextLabel(number: "5")
    }
    @IBAction func sixButtonTapped(_ sender: Any) {
        checkIfAnsWasTapped()
        addNumberToAnswerTextLabel(number: "6")
    }
    @IBAction func sevenButtonTapped(_ sender: Any) {
        checkIfAnsWasTapped()
        addNumberToAnswerTextLabel(number: "7")
    }
    @IBAction func eightButtonTapped(_ sender: Any) {
        checkIfAnsWasTapped()
        addNumberToAnswerTextLabel(number: "8")
    }
    @IBAction func nineButtonTapped(_ sender: Any) {
        checkIfAnsWasTapped()
        addNumberToAnswerTextLabel(number: "9")
    }
    //operation actions
    @IBAction func divisionButtonTapped(_ sender: Any) {
        operationButtonTapped(operand: "/")
    }
    @IBAction func multiplicationButtonTapped(_ sender: Any) {
        operationButtonTapped(operand: "*")
    }
    @IBAction func additionButtonTapped(_ sender: Any) {
        operationButtonTapped(operand: "+")
    }
    @IBAction func subtractionButtonTapped(_ sender: Any) {
        operationButtonTapped(operand: "-")
    }
    @IBAction func ansButtonTapped(_ sender: Any) {
        calculateAnswer()
        storedValue = 0
    }
    @IBAction func clearButtonTapped(_ sender: Any) {
        answerTextLabel.text = ""
        equationTextLabel.text = ""
    }
    
    //MARK: - Functions
    
    func addNumberToAnswerTextLabel(number: String) {
        
        guard let string = answerTextLabel.text else {return}
        answerTextLabel.text = string + number
    }
    
    func operationButtonTapped(operand: String) {
        guard let firstNumber = answerTextLabel.text else {return}
        guard let unwrappedNumber = Double(firstNumber) else {return}
        guard let equationText = equationTextLabel.text else {return}
        equationTextLabel.text = equationText + firstNumber

        storedValue = unwrappedNumber
        if operand == "+" {
            self.operand = operand
            equationTextLabel.text = equationTextLabel.text! + " \(operand) "
            answerTextLabel.text = ""
            
        } else if operand == "-" {
            self.operand = operand
            equationTextLabel.text = equationTextLabel.text! + " \(operand) "
            answerTextLabel.text = ""
            
        } else if operand == "/" {
            self.operand = operand
            equationTextLabel.text = equationTextLabel.text! +  " \(operand) "
            answerTextLabel.text = ""
            
        } else if operand == "*" {
            self.operand = operand
            equationTextLabel.text = equationTextLabel.text! + " x "
            answerTextLabel.text = ""
        }
        print(self.operand)
        print(storedValue)
    }
    
    func calculateAnswer() {
        guard let secondNumber = answerTextLabel.text else {return}
        guard let unwrappedNumber = Double(secondNumber) else {return}
        guard let equationText = equationTextLabel.text else {return}
        
        ansWasTapped.toggle()
        
        var finalAnswer: String = ""
        
        if operand == "+" {
            let answer = storedValue  + unwrappedNumber
            answerTextLabel.text = String(answer)
            finalAnswer = String(answer)
            
        } else if operand == "-" {
            let answer = storedValue  - unwrappedNumber
            answerTextLabel.text = String(answer)
            finalAnswer = String(answer)
            
        } else if operand == "/" {
            let answer = storedValue  / unwrappedNumber
            answerTextLabel.text = String(answer)
            finalAnswer = String(answer)
            
        } else if operand == "*" {
            let answer = storedValue  * unwrappedNumber
            answerTextLabel.text = String(answer)
            finalAnswer = String(answer)
        }
        
        if finalAnswer != "" {
            equationTextLabel.text = equationText + secondNumber + " = " + finalAnswer
        }
        
    }
    
    func checkIfAnsWasTapped() {
        
        if ansWasTapped {
            equationTextLabel.text = ""
            answerTextLabel.text = ""
            ansWasTapped.toggle()
        }
    }
    
    
}//End of Class

