//
//  StyleGuide.swift
//  Calculator
//
//  Created by Justin Webster on 5/17/21.
//

import UIKit

extension UIView {
    
    func addCornerRadius(_ radius: CGFloat = 10) {
        self.layer.cornerRadius = radius
    }
    
    func addAccentBorder(width: CGFloat = 1, color: UIColor = Colors.customBlue) {
        self.layer.borderWidth = width
        self.layer.borderColor = color.cgColor
    }
}//End of Extension


struct Colors {
    static let customGreen = UIColor(red: 50/255, green: 216/255, blue: 127/255, alpha: 1)
    static let customBlue = UIColor(red: 0/255, green: 149/255, blue: 242/255, alpha: 1)
    static let lighterGray = UIColor(red: 178/255, green: 178/255, blue: 178/255, alpha: 1)
}

struct FontNames {
    static let verdanaBold = "Verdana-Bold"
    static let trebuchet = "TrebuchetMS"
    static let trebuchetBold = "TrebuchetMS-Bold"
}
