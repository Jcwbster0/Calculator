//
//  operationButton.swift
//  Calculator
//
//  Created by Justin Webster on 5/17/21.
//

import UIKit

class OperationButton: UIButton {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setupButton()
    }
    
    func setupButton() {
        
        self.backgroundColor = Colors.customBlue
        tintColor = .white
        self.addCornerRadius()
        self.updateFontTo(font: FontNames.trebuchetBold)
    }
    
    func updateFontTo(font: String) {
        guard let size = self.titleLabel?.font.pointSize else {return}
        self.titleLabel?.font = UIFont(name: font, size: size)
    }
}

