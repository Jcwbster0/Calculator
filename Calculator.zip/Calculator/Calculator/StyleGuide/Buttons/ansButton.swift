//
//  ansButton.swift
//  Calculator
//
//  Created by Justin Webster on 5/17/21.
//

import UIKit

class ansButton: UIButton {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setupButton()
    }
    
    func setupButton() {
        
        self.backgroundColor = Colors.customGreen
        setTitleColor(.white, for: .normal)
        self.addCornerRadius()
        self.updateFontTo(font: FontNames.trebuchetBold)
    }
    
    func updateFontTo(font: String) {
        guard let size = self.titleLabel?.font.pointSize else {return}
        self.titleLabel?.font = UIFont(name: font, size: size)
    }
    
}//End of Class

