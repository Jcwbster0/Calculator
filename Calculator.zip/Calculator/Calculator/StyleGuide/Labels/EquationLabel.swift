//
//  EquationLabel.swift
//  Calculator
//
//  Created by Justin Webster on 5/17/21.
//

import UIKit

class EquationLabel: UILabel {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setup()
    }
    func setup() {
        self.addAccentBorder(color: Colors.customGreen)
        self.addCornerRadius()
    }
    
}
