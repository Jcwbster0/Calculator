//
//  ResultLabel.swift
//  Calculator
//
//  Created by Justin Webster on 5/17/21.
//

import UIKit

class ResultLabel: UILabel {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setup()
    }
    func setup() {
        self.addAccentBorder()
        self.addCornerRadius()
    }
    
}
